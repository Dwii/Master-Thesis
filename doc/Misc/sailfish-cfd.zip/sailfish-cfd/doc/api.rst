Sailfish API
============

Simulation
----------
.. automodule:: lbm
   :members:

Geometry
--------
.. automodule:: geo
   :members:

Symbolic computation
--------------------
.. automodule:: sym
   :members:

